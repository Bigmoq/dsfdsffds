package com.wedding.zafaf;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
